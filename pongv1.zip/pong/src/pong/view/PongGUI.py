# package pong.view
import pygame
import time

from pong.model import *
from pong.event.ModelEvent import ModelEvent
from pong.event.EventBus import EventBus
from pong.event.EventHandler import EventHandler
from pong.view.theme.Cool import Cool
from pong.view.theme.Duckie import Duckie

from pong.model.Paddle import PADDLE_SPEED
from pong.model.Config import *

from pong.model.Ball import Ball
from pong.view.Assets import Assets
from pong.model.Paddle import *
from pong.model.Pong import Pong

pygame.init()


class PongGUI:
    """
    The GUI for the Pong game (except the menu).
    No application logic here just GUI and event handling.

    Run this to run the game.

    See: https://en.wikipedia.org/wiki/Pong
    """
    running = False  # Is game running?
    screen = pygame.display.set_mode([GAME_WIDTH, GAME_HEIGHT])
    BLACK = (0, 0, 0)
    RED = (255, 0, 0)
    BLUE = (0, 0, 255)
    points_font = pygame.font.SysFont('Ariel', 36)
    clock = pygame.time.Clock()

    # ------- Keyboard handling ----------------------------------
    @classmethod
    def key_pressed(cls, event):
        if not cls.running:
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                # TODO
                pass
            elif event.key == pygame.K_DOWN:
                # TODO
                pass
            elif event.key == pygame.K_q:
                # TODO
                pass
            elif event.key == pygame.K_a:
                # TODO
                pass

    @classmethod
    def key_released(cls, event):
        if not cls.running:
            return
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                # TODO
                pass
            elif event.key == pygame.K_DOWN:
                # TODO
                pass
            elif event.key == pygame.K_q:
                # TODO
                pass
            elif event.key == pygame.K_a:
                # TODO
                pass

    # ---- Menu handling (except themes) -----------------

    # TODO Optional

    @classmethod
    def new_game(cls):
        # TODO rebuild OO model as needed
        pass

    @classmethod
    def kill_game(cls):
        cls.running = False
        # TODO kill all aspects of game

    # -------- Event handling (events sent from model to GUI) ------------

    class ModelEventHandler(EventHandler):
        def on_model_event(self, evt: ModelEvent):
            if evt.event_type == ModelEvent.EventType.NEW_BALL:
                # TODO Optional
                pass
            elif evt.event_type == ModelEvent.EventType.BALL_HIT_PADDLE:
                PongGUI.assets.ball_hit_paddle_sound.play()
            elif evt.event_type == ModelEvent.EventType.BALL_HIT_WALL_CEILING:
                # TODO Optional
                pass

    # ################## Nothing to do below ############################

    # ---------- Theme handling ------------------------------

    assets = Cool()

    @classmethod
    def handle_theme(cls, menu_event):
        s = "Cool"  # ((MenuItem) menu_event.getSource()).getText()
        last_theme = cls.assets
        try:
            if s == "Cool":
                cls.assets = Cool()
            elif s == "Duckie":
                cls.assets = Duckie()
            else:
                raise ValueError("No such assets " + s)
        except IOError as ioe:
            cls.assets = last_theme

    # ---------- Rendering -----------------
    @classmethod
    def render(cls):
        cls.__draw_background()
        cls._draw_points()
        cls.__draw_ball()
        cls.__draw_paddles()
        cls.__game_over_txt()
        pygame.display.flip()
        # TODO

    @classmethod
    def __draw_background(cls):
        bg = cls.assets.get_background()
        bg_scale = pygame.transform.scale(bg, (GAME_WIDTH, GAME_HEIGHT))
        cls.screen.blit(bg_scale, (0, 0))

    @classmethod
    def _draw_points(cls):
        cls.__draw_points_left()
        cls.__draw_points_right()

    @classmethod
    def __draw_points_right(cls):
        points_right = Pong.get_points_right()
        txt_right = f"Points: {points_right}"
        img_right = cls.points_font.render(txt_right, True, cls.RED)
        rect_right = img_right.get_rect()
        rect_right.topleft = (470, 20)
        cls.screen.blit(img_right, rect_right)

    @classmethod
    def __draw_points_left(cls):
        points_left = Pong.get_points_left()
        txt_left = f"Points: {points_left}"
        img_left = cls.points_font.render(txt_left, True, cls.BLUE)
        rect_left = img_left.get_rect()
        rect_left.topleft = (20, 20)
        cls.screen.blit(img_left, rect_left)

    @classmethod
    def __draw_ball(cls):
        ball_position = Pong.get_ball()
        if ball_position is not None:
            ball = cls.assets.object_image_map[Ball]
            ball_scale = pygame.transform.scale(ball, (Ball.WIDTH, Ball.HEIGHT))
            cls.screen.blit(ball_scale, (ball_position.get_x(), ball_position.get_y()))

    @classmethod
    def __draw_paddles(cls):
        cls.__draw_left_paddle()
        cls.__draw_right_paddle()

    @classmethod
    def __draw_right_paddle(cls):
        right_paddle = Pong.get_right_paddle()
        right_paddle_img = Assets.get_image(Assets.right_paddle_img_file)
        right_paddle_img_scale = pygame.transform.scale(right_paddle_img, (PADDLE_WIDTH, PADDLE_HEIGHT))
        cls.screen.blit(right_paddle_img_scale, (580, right_paddle.get_y()))

    @classmethod
    def __draw_left_paddle(cls):
        left_paddle = Pong.get_left_paddle()
        left_paddle_img = Assets.get_image(Assets.left_paddle_img_file)
        left_paddle_img_scale = pygame.transform.scale(left_paddle_img, (PADDLE_WIDTH, PADDLE_HEIGHT))
        cls.screen.blit(left_paddle_img_scale, (10, left_paddle.get_y()))

    @classmethod
    def __game_over_txt(cls):
        pass

    # ---------- Game loop ----------------

    @classmethod
    def run(cls):
        while True:
            cls.clock.tick(GAME_SPEED)
            Pong.update(time.time_ns())
            cls.update()
            cls.handle_events()

    @classmethod
    def update(cls):
        # TODO
        cls.render()

    @classmethod
    def handle_events(cls):
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.KEYDOWN:
                cls.__key_press(event)
            elif event.type == pygame.KEYUP:
                cls.__key_release(event)

    @classmethod
    def __key_press(cls, event):
        if event.key == pygame.K_UP:
            Pong.set_speed_right_paddle(-PADDLE_SPEED)
        elif event.key == pygame.K_DOWN:
            Pong.set_speed_right_paddle(PADDLE_SPEED)
        if event.key == pygame.K_w:
            Pong.set_speed_left_paddle(-PADDLE_SPEED)
        elif event.key == pygame.K_s:
            Pong.set_speed_left_paddle(PADDLE_SPEED)

    @classmethod
    def __key_release(cls, event):
        if event.key in [pygame.K_DOWN, pygame.K_UP]:
            Pong.set_speed_right_paddle(0)
        if event.key in [pygame.K_w, pygame.K_s]:
            Pong.set_speed_left_paddle(0)
