# package pong.model
import random

import pong.event.ModelEvent
import pong.event.EventBus
from pong.model.Ball import Ball
from pong.model.Paddle import Paddle
from pong.model.Paddle import PADDLE_WIDTH, PADDLE_HEIGHT, PADDLE_SPEED
from pong.model.Config import *

class Pong:
    """
     * Logic for the Pong Game
     * Model class representing the "whole" game
     * Nothing visual here
    """
    # TODO More attributes
    points_left = 0
    points_right = 0

    ball = None
    left_paddle = Paddle(10, GAME_HEIGHT/2 - PADDLE_HEIGHT/2, PADDLE_WIDTH, PADDLE_HEIGHT)
    right_paddle = Paddle(GAME_WIDTH - 20, GAME_HEIGHT/2 - PADDLE_HEIGHT/2, PADDLE_WIDTH, PADDLE_HEIGHT)
    # TODO Initialization

    # --------  Game Logic -------------

    timeForLastHit = 0         # To avoid multiple collisions

    @classmethod
    def update(cls, now):
        cls.right_paddle.move()
        cls.left_paddle.move()
        ball = cls.ball
        if ball is None:
            ball = cls.create_ball()
            cls.ball = ball
        if ball is not None:
            ball.move()
            is_left = ball.get_x() < -1
            is_right = ball.get_x() > GAME_WIDTH + 1
            celling = ball.get_y() < 0
            floor = ball.get_min_y() > GAME_HEIGHT
            if is_right or is_left:
                if is_right:
                    cls.points_left += 1
                else:
                    cls.points_right += 1
                cls.ball = None
            if floor or celling:
                Ball.change_dy(ball)

            if cls.left_paddle.get_y() <= 0:
                cls.left_paddle.y = 1
            if cls.left_paddle.get_min_y() >= GAME_HEIGHT:
                cls.left_paddle.y = GAME_HEIGHT - (PADDLE_HEIGHT + 1)
            if cls.right_paddle.get_y() <= 0:
                cls.right_paddle.y = 1
            if cls.right_paddle.get_min_y() >= GAME_HEIGHT:
                cls.right_paddle.y = GAME_HEIGHT - (PADDLE_HEIGHT + 1)
            """
            if cls.right_paddle.get_y() < ball.get_y() < cls.right_paddle.get_min_y():
                if cls.right_paddle.get_x() < ball.get_x_to_the_right() < cls.right_paddle.get_x_to_the_right():
                    ball.change_dx()

            if cls.left_paddle.get_y() < ball.get_y() < cls.left_paddle.get_min_y():
                if cls.left_paddle.get_x() < ball.get_x() < cls.left_paddle.get_x_to_the_right():
                    ball.change_dx()"""

            if cls.right_paddle.get_x() < ball.get_x_to_the_right() < cls.right_paddle.get_x_to_the_right():
                print(cls.right_paddle.get_y(), ball.get_y(), cls.right_paddle.get_min_y())
                if cls.right_paddle.get_y() < ball.get_y() < cls.right_paddle.get_min_y():
                    ball.change_dx()
                elif cls.right_paddle.get_y() < ball.get_min_y() < cls.right_paddle.get_min_y():
                    ball.change_dx()

            if cls.left_paddle.get_x() < ball.get_x() < cls.left_paddle.get_x_to_the_right():
                print(cls.right_paddle.get_y(), ball.get_y(), cls.right_paddle.get_min_y())
                if cls.left_paddle.get_y() < ball.get_y() < cls.left_paddle.get_min_y():
                    ball.change_dx()
                elif cls.left_paddle.get_y() < ball.get_min_y() < cls.left_paddle.get_min_y():
                    ball.change_dx()
        # TODO Game logic here

    @classmethod
    def create_ball(cls):
        dx = random.randint(1, 4)
        dy = 5 - dx
        if random.randint(0, 1) == 0:
            dy = -dy
        return Ball(GAME_WIDTH/2 - Ball.WIDTH/2, GAME_HEIGHT/2 - Ball.HEIGHT/2, 40, 40, dx, dy)

    # --- Used by GUI  ------------------------
    @classmethod
    def get_all_items_with_position(cls):
        drawables = []
        # TODO
        return drawables

    @classmethod
    def get_points_left(cls):
        return cls.points_left

    @classmethod
    def get_points_right(cls):
        return cls.points_right

    @classmethod
    def set_speed_right_paddle(cls, dy):
        cls.right_paddle.set_dy(dy)

    @classmethod
    def set_speed_left_paddle(cls, dy):
        cls.left_paddle.set_dy(dy)

    @classmethod
    def get_ball(cls):
        return cls.ball

    @classmethod
    def get_right_paddle(cls):
        return cls.right_paddle

    @classmethod
    def get_left_paddle(cls):
        return cls.left_paddle

