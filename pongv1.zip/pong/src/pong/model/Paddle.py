# package pong.model

from pong.model.Config import GAME_HEIGHT

PADDLE_WIDTH = 10
PADDLE_HEIGHT = 60
PADDLE_SPEED = 5


# A Paddle for the Pong game
class Paddle:

    def __init__(self, x, y, width, height, dy=0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.dy = dy

    def intersects(self):
        pass

    def stop(self):
        self.dy = 0

    def move(self):
        self.y += self.dy

    def set_dy(self, dy):
        self.dy = dy

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def get_min_y(self):
        return self.y + self.height

    def get_x_to_the_right(self):
        return self.x + PADDLE_WIDTH
