# package pong.model

from pong.model.Config import GAME_WIDTH, GAME_HEIGHT, BALL_SPEED_FACTOR
"""
 * A Ball for the Pong game
 * A model class
"""


class Ball:
    WIDTH = 40
    HEIGHT = 40

    def __init__(self, x, y, width, height, dx=0, dy=0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.dx = dx
        self.dy = dy

    def move(self):
        self.x += self.dx
        self.y += self.dy

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get_center_x(self):
        return self.x - self.width / 2

    def get_center_y(self):
        return self.y - self.height / 2

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def get_min_x(self):
        return self.x + self.width

    def get_min_y(self):
        return self.y + self.height

    def change_dy(self):
        self.dy = -self.dy

    def change_dx(self):
        self.dx = -self.dx * BALL_SPEED_FACTOR

    def get_x_to_the_right(self):
        return self.x + self.width

    def get_left_impact_area(self):
        return self.y + self.height


