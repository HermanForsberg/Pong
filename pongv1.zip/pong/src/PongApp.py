from pong.view.PongGUI import PongGUI

if __name__ == '__main__':
    PongGUI.run()
