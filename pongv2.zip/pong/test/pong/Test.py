# package pong

import pong.model.Ball as Ball


class Test:
    """
     * Here you should write your tests
     *
     * Right click and run ...
    """
    @staticmethod
    def test():
        b = Ball()
        print("ssss")
        # Create an object  ...
        # .. call methods to test.
