# package pong.model

from pong.model.Movable import Movable

PADDLE_WIDTH = 10
PADDLE_HEIGHT = 60
PADDLE_SPEED = 5


# A Paddle for the Pong game
class Paddle(Movable):

    def __init__(self, x, y, width, height, dy=0, dx=0):
        super().__init__(x, y, width, height, dx, dy)
