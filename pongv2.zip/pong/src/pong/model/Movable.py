from pong.model.Positionable import Positionable
from pong.model.Config import BALL_SPEED_FACTOR


class Movable(Positionable):
    def __init__(self, x, y, width, height, dx, dy):
        super().__init__(x, y, width, height)
        self.dy = dy
        self.dx = dx

    def move(self):
        self.x += self.dx
        self.y += self.dy

    def change_direction_of_dy(self):
        self.dy = -self.dy

    def change_dx(self):
        self.dx = -self.dx * BALL_SPEED_FACTOR

    def change_speed_of_dy(self):
        self.dy = self.dy * BALL_SPEED_FACTOR

    def stop(self):
        self.dy = 0

    def set_dy(self, dy):
        self.dy = dy
