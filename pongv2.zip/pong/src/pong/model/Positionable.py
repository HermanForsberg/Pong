class Positionable:
    def __init__(self, x, y, width, height):
        self.height = height
        self.y = y
        self.width = width
        self.x = x

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get_center_x(self):
        return self.x - self.width / 2

    def get_center_y(self):
        return self.y - self.height / 2

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def get_min_x(self):
        return self.x + self.width

    def get_min_y(self):
        return self.y + self.height

    def get_x_to_the_right(self):
        return self.x + self.width
