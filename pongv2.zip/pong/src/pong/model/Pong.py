# package pong.model
import random

from pong.model.Ball import Ball
from pong.model.Paddle import Paddle
from pong.model.Paddle import PADDLE_WIDTH, PADDLE_HEIGHT
from pong.model.Config import *


class Pong:
    """
     * Logic for the Pong Game
     * Model class representing the "whole" game
     * Nothing visual here
    """
    # TODO More attributes
    points_left = 0
    points_right = 0

    ball = None
    left_paddle = Paddle(10, GAME_HEIGHT/2 - PADDLE_HEIGHT/2, PADDLE_WIDTH, PADDLE_HEIGHT)
    right_paddle = Paddle(GAME_WIDTH - 20, GAME_HEIGHT/2 - PADDLE_HEIGHT/2, PADDLE_WIDTH, PADDLE_HEIGHT)
    # TODO Initialization

    # --------  Game Logic -------------

    timeForLastHit = 0         # To avoid multiple collisions

    @classmethod
    def update(cls, now):
        cls.right_paddle.move()
        cls.left_paddle.move()
        ball = cls.ball
        if ball is None:
            ball = cls.create_ball()
            cls.ball = ball
        if ball is not None:
            cls.__ball_bounce_on_bounds(ball)
            cls.__ball_out_of_bounds(ball)
            cls.__paddle_bounds(cls.right_paddle)
            cls.__paddle_bounds(cls.left_paddle)
            cls.__paddle_impact(ball.get_x_to_the_right(), ball.get_y(), ball.get_min_y(), ball, cls.right_paddle)
            cls.__paddle_impact(ball.get_x(), ball.get_y(), ball.get_min_y(), ball, cls.left_paddle)

    @classmethod
    def __ball_bounce_on_bounds(cls, ball):
        celling = ball.get_y() < 0
        floor = ball.get_min_y() > GAME_HEIGHT
        if floor or celling:
            Ball.change_direction_of_dy(ball)

    @classmethod
    def __ball_out_of_bounds(cls, ball):
        ball.move()
        is_left = ball.get_x() < -1
        is_right = ball.get_x() > GAME_WIDTH + 1
        if is_right or is_left:
            if is_right:
                cls.points_left += 1
            else:
                cls.points_right += 1
            cls.ball = None

    @classmethod
    def __paddle_bounds(cls, paddle):
        if paddle.get_y() <= 0:
            paddle.y = 1
        if paddle.get_min_y() >= GAME_HEIGHT:
            paddle.y = GAME_HEIGHT - (PADDLE_HEIGHT + 1)

    @classmethod
    def __paddle_impact(cls, x_coord, y_coord_max, y_coord_min, ball, paddle):
        if paddle.get_x() < x_coord < paddle.get_x_to_the_right():
            if paddle.get_y() < y_coord_max < paddle.get_min_y():
                ball.change_dx()
                ball.change_speed_of_dy()
            elif paddle.get_y() < y_coord_min < paddle.get_min_y():
                ball.change_dx()
                ball.change_speed_of_dy()

    @classmethod
    def create_ball(cls):
        dx = random.randint(1, 4)
        dy = 5 - dx
        if random.randint(0, 1) == 0:
            dy = -dy
        return Ball(GAME_WIDTH/2 - Ball.WIDTH/2, GAME_HEIGHT/2 - Ball.HEIGHT/2, 40, 40, dx, dy)

    # --- Used by GUI  ------------------------
    @classmethod
    def get_all_items_with_position(cls):
        drawables = []
        # TODO
        return drawables

    @classmethod
    def get_points_left(cls):
        return cls.points_left

    @classmethod
    def get_points_right(cls):
        return cls.points_right

    @classmethod
    def set_speed_right_paddle(cls, dy):
        cls.right_paddle.set_dy(dy)

    @classmethod
    def set_speed_left_paddle(cls, dy):
        cls.left_paddle.set_dy(dy)

    @classmethod
    def get_ball(cls):
        return cls.ball

    @classmethod
    def get_right_paddle(cls):
        return cls.right_paddle

    @classmethod
    def get_left_paddle(cls):
        return cls.left_paddle
