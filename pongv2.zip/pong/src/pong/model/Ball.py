# package pong.model

from pong.model.Movable import Movable

"""
 * A Ball for the Pong games
 * A model class
"""


class Ball(Movable):
    WIDTH = 40
    HEIGHT = 40

    def __init__(self, x, y, width, height, dx, dy):
        super().__init__(x, y, width, height, dx, dy)
